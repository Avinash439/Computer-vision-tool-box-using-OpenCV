function varargout = MyGUI(varargin)
% MYGUI M-file for MyGUI.fig
%      MYGUI, by itself, creates a new MYGUI or raises the existing
%      singleton*.
%
%      H = MYGUI returns the handle to a new MYGUI or the handle to
%      the existing singleton*.
%
%      MYGUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in MYGUI.M with the given input arguments.
%
%      MYGUI('Property','Value',...) creates a new MYGUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before MyGUI_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to MyGUI_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help MyGUI

% Last Modified by GUIDE v2.5 06-Jun-2017 23:06:46

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
    'gui_Singleton',  gui_Singleton, ...
    'gui_OpeningFcn', @MyGUI_OpeningFcn, ...
    'gui_OutputFcn',  @MyGUI_OutputFcn, ...
    'gui_LayoutFcn',  [] , ...
    'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before MyGUI is made visible.
function MyGUI_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to MyGUI (see VARARGIN)

% Choose default command line output for MyGUI
handles.output = hObject;
set(handles.pushbutton1,'visible','off');
set(handles.pushbutton2,'visible','off');
set(handles.pushbutton3,'visible','off');
set(handles.pushbutton4,'visible','off');
set(handles.pushbutton5,'visible','off');
set(handles.text4,'visible','off');
set(handles.slider1,'visible','off');
set(handles.text5,'visible','off');
set(handles.text6,'visible','off');
set(handles.text7,'visible','off');
set(handles.text8,'visible','off');
set(handles.text9,'visible','off');
set(handles.edit2,'visible','off');
% Update handles structure
guidata(hObject, handles);

% UIWAIT makes MyGUI wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = MyGUI_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on selection change in popupmenu1.
function popupmenu1_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu1


% --- Executes during object creation, after setting all properties.


s = get(handles.popupmenu1,'value');
switch s
    %saving the image
    case 2
        [FileName, PathName] = uiputfile('*.jpg', 'Save As');
        Name = fullfile(PathName,FileName);
        axes(handles.axes2)
        f = getframe();
        im = frame2im(f);
        imwrite(im,Name,'jpg');
        
    case 3
        axes(handles.axes1)
        cla reset
        axes(handles.axes2)
        cla reset
        %open the image
        [filename,pathname]= uigetfile({'*.jpg;*.tif;*.png;*.gif','All Image Files';...
            '*.*\','All Files' });
        image=imread(fullfile(pathname,filename));
        image1 = rgb2gray(image);
        handles.image=image1;
        guidata(hObject,handles);
        % imshow(image);
        axes(handles.axes1);imshow(handles.image);
        
        
    case 4
        %open a video
        [filename,pathname] = uigetfile({'*.mp4;*.avi;*','All Video Files'});
        filename =(fullfile(pathname,filename));
        setappdata(0,'filename',filename);
        v = vision.VideoFileReader(filename, 'ImageColorSpace', 'rgb');
        frame = step(v);
        axes(handles.axes1);
        imshow(frame);
        setappdata(0,'v',v);
        set(handles.pushbutton4,'visible','on');
        set(handles.pushbutton5,'visible','on');
    case 5
        %Reset
        set(handles.text9,'visible','off');
        set(handles.pushbutton1,'visible','off');
        set(handles.pushbutton2,'visible','off');
        set(handles.pushbutton3,'visible','off');
        set(handles.pushbutton4,'visible','off');
        set(handles.pushbutton5,'visible','off');
        set(handles.text4,'visible','off');
        set(handles.slider1,'visible','off');
        set(handles.text5,'visible','off');
        set(handles.text6,'visible','off');
        set(handles.text7,'visible','off');
        set(handles.text8,'visible','off');
        set(handles.edit2,'visible','off');
        axes(handles.axes1);
        hold off;
        cla reset;
        axes(handles.axes2);
        hold off;
        cla reset;
    case 6
        %exit button
        axes(handles.axes1)
        cla reset
        axes(handles.axes2)
        cla reset
        close all;
end

function popupmenu1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popupmenu2.
function popupmenu2_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
w = get(handles.popupmenu2,'value');
image1=handles.image;
switch w
    case 2
        set(handles.edit2,'visible','on');
        set(handles.pushbutton1,'visible','off');
        set(handles.pushbutton2,'visible','off');
        set(handles.pushbutton3,'visible','off');
        set(handles.text4,'visible','off');
        set(handles.slider1,'visible','on');
        set(handles.text5,'visible','off');
        set(handles.text6,'visible','off');
        set(handles.text7,'visible','off');
        set(handles.text8,'visible','off');
        set(handles.text9,'visible','on');
        set(handles.slider1,'min',0);
        set(handles.slider1,'value',0.05);
        set(handles.slider1,'max',1);%salt and peppernoise
        new_i=imnoise(handles.image,'salt & pepper', 0.05); %noise added in this step for a 5% corrupted pixels
        axes(handles.axes2);
        imshow(new_i,[]);
        
        
    case 3
        %// Load in MATLAB logo
        set(handles.text9,'visible','off');
        set(handles.pushbutton1,'visible','off');
        set(handles.pushbutton2,'visible','off');
        set(handles.pushbutton3,'visible','off');
        set(handles.text4,'visible','off');
        set(handles.slider1,'visible','off');
        set(handles.text5,'visible','off');
        set(handles.text6,'visible','off');
        set(handles.text7,'visible','off');
        set(handles.text8,'visible','off');
        set(handles.edit2,'visible','off');
        %adding logo
        [filename,pathname]= uigetfile({'*.jpg;*.tif;*.png;*.gif,*.bmp','All Image Files';...
            '*.*\','All Files' });
        logo =imread(fullfile(pathname,filename));
        logo1 = rgb2gray(logo);
        
        
        
        
        %// Resize the MATLAB logo
        logoResize = imresize(logo1, 0.1, 'bilinear');
        
        %// Get the size of the resized logo - we need this
        %// to properly mix the stuff in
        rows = size(logoResize, 1);
        cols = size(logoResize, 2);
        
        %// Specify alpha here
        alpha = 0.9;
        
        %specifying the place for the logo in the image
        image1(end-rows+1:end,end-cols+1:end,:) = uint8(alpha.*double(logoResize) + ...
            (1-alpha).*double(image1(end-rows+1:end,end-cols+1:end,:)));
        
        %showing the display sepcified to axis2
        axes(handles.axes2);
        imshow(image1,[]);
        
    case 4
        set(handles.text9,'visible','off');
        set(handles.pushbutton1,'visible','off');
        set(handles.pushbutton2,'visible','off');
        set(handles.pushbutton3,'visible','off');
        set(handles.text4,'visible','off');
        set(handles.slider1,'visible','off');
        set(handles.text5,'visible','off');
        set(handles.text6,'visible','off');
        set(handles.text7,'visible','off');
        set(handles.text8,'visible','off');
        set(handles.edit2,'visible','off');
        
        %         imgRGB=handles.image;
        %         cform=makecform('srgb2xyz');
        %         imgxyz=applycform(imgRGB,cform)
        %         axes(handles.axes2); imshow(imgxyz,[]);
        rgb =  image;
        C = makecform('srgb2lab');
        lab = applycform(rgb,C);
        lab_2 = colorspace('lab<-rgb', rgb);
        imgxyz = lab2uint8(lab_2);
        axes(handles.axes2); imshow(imgxyz,[]);
    case 5
        
        %         imhist(handles.image);
        %         axes(handles.axes2);
        set(handles.text9,'visible','off');
        set(handles.pushbutton1,'visible','off');
        set(handles.pushbutton2,'visible','off');
        set(handles.pushbutton3,'visible','off');
        set(handles.text4,'visible','off');
        set(handles.slider1,'visible','off');
        set(handles.text5,'visible','off');
        set(handles.text6,'visible','off');
        set(handles.text7,'visible','off');
        set(handles.text8,'visible','off');
        set(handles.edit2,'visible','off');
        [counts,binLocations] = imhist(handles.image);%histogram of an image
        stem(handles.axes2,binLocations,counts);
    case 6
        set(handles.text9,'visible','off');
        set(handles.pushbutton1,'visible','off');
        set(handles.pushbutton2,'visible','off');
        set(handles.pushbutton3,'visible','off');
        set(handles.text4,'visible','off');
        set(handles.slider1,'visible','off');
        set(handles.text5,'visible','off');
        set(handles.text6,'visible','off');
        set(handles.text7,'visible','off');
        set(handles.text8,'visible','off');
        set(handles.edit2,'visible','off');
        z=histeq(handles.image);%histogram equalization
        axes(handles.axes2);
        imshow(z,[]);
    case 7
        set(handles.text9,'visible','off');
        set(handles.pushbutton1,'visible','off');
        set(handles.pushbutton2,'visible','off');
        set(handles.pushbutton3,'visible','off');
        set(handles.text4,'visible','off');
        set(handles.slider1,'visible','on');
        set(handles.text5,'visible','on');
        set(handles.edit2,'visible','off');
        Blur = imgaussfilt(handles.image,1);%blurring the image with the guassian filter
        axes(handles.axes2);
        imshow(Blur,[]);
        set(handles.slider1,'min',0.01);
        set(handles.slider1,'value',0.05);
        set(handles.slider1,'max',20);
        
    case 8
        set(handles.text9,'visible','off');
        set(handles.pushbutton1,'visible','off');
        set(handles.pushbutton2,'visible','off');
        set(handles.pushbutton3,'visible','off');
        set(handles.text4,'visible','off');
        set(handles.slider1,'visible','off');
        set(handles.text5,'visible','off');
        set(handles.text6,'visible','off');
        set(handles.edit2,'visible','off');
        S = fspecial('sobel');%extractingedges from sobel operator
        edgeIm= imfilter(handles.image, S);
        axes(handles.axes2);
        imshow(edgeIm,[]);
    case 9
        set(handles.text9,'visible','off');
        set(handles.pushbutton1,'visible','off');
        set(handles.pushbutton2,'visible','off');
        set(handles.pushbutton3,'visible','off');
        set(handles.text4,'visible','off');
        set(handles.slider1,'visible','off');
        set(handles.text5,'visible','off');
        set(handles.slider1,'visible','on');
        set(handles.text6,'visible','on');
        set(handles.edit2,'visible','off');
        %second derivative of image
        L = fspecial('laplacian');
        set(handles.slider1,'min',0);
        set(handles.slider1,'value',0.2);
        set(handles.slider1,'max',1);
        edgeIm= imfilter(handles.image, L);
        axes(handles.axes2);
        imshow(edgeIm,[]);
    case 10
        set(handles.edit2,'visible','off');
        set(handles.pushbutton1,'visible','off');
        set(handles.text9,'visible','off');
        set(handles.pushbutton2,'visible','off');
        set(handles.pushbutton3,'visible','off');
        set(handles.text4,'visible','off');
        set(handles.slider1,'visible','off');
        set(handles.text5,'visible','off');
        set(handles.slider1,'visible','off');
        set(handles.text6,'visible','off');
        set(handles.slider1,'visible','on');
        set(handles.text7,'visible','on');
        sharp=imsharpen(handles.image,'Amount',0.2);%sharpening the image
        axes(handles.axes2);
        imshow(sharp,[]);
        
end

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu2 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu2

% --- Executes during object creation, after setting all properties.
function popupmenu2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popupmenu3.
function popupmenu3_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu3 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu3


w1 = get(handles.popupmenu3,'value');
image1=handles.image;
switch w1
    case 2
        %morphological operations
        se = strel('disk',5);
        Open=imopen(handles.image,se);%opening
        axes(handles.axes2);
        imshow(Open,[]);
        set(handles.text9,'visible','off');
        set(handles.pushbutton1,'visible','on');
        set(handles.pushbutton2,'visible','on');
        set(handles.pushbutton3,'visible','on');
        set(handles.text4,'visible','on');
        set(handles.text5,'visible','off');
        set(handles.slider1,'visible','off');
        set(handles.text6,'visible','off');
        set(handles.text7,'visible','off');
        set(handles.text8,'visible','off');
        set(handles.edit2,'visible','off');
        
    case 3
        se = strel('disk',5);
        close=imclose(handles.image,se);%closing
        axes(handles.axes2);
        imshow(close,[]);
        set(handles.text9,'visible','off');
        set(handles.pushbutton1,'visible','on');
        set(handles.pushbutton2,'visible','on');
        set(handles.pushbutton3,'visible','on');
        set(handles.text4,'visible','on');
        set(handles.text5,'visible','off');
        set(handles.slider1,'visible','off');
        set(handles.text6,'visible','off');
        set(handles.text7,'visible','off');
        set(handles.text8,'visible','off');
        set(handles.edit2,'visible','off');
    case 4
        se = strel('disk',5);
        dilate=imdilate(handles.image,se);%dilation
        axes(handles.axes2);
        imshow(dilate,[]);
        set(handles.pushbutton1,'visible','on');
        set(handles.pushbutton2,'visible','on');
        set(handles.pushbutton3,'visible','on');
        set(handles.text4,'visible','on');
        set(handles.text5,'visible','off');
        set(handles.slider1,'visible','off');
        set(handles.text6,'visible','off');
        set(handles.text7,'visible','off');
        set(handles.text8,'visible','off');
        set(handles.text9,'visible','off');
        set(handles.edit2,'visible','off');
    case 5
        se = strel('disk',5);
        erode=imerode(handles.image,se);%erode
        axes(handles.axes2);
        imshow(erode,[]);
        set(handles.pushbutton1,'visible','on');
        set(handles.pushbutton2,'visible','on');
        set(handles.pushbutton3,'visible','on');
        set(handles.text4,'visible','on');
        set(handles.text5,'visible','off');
        set(handles.slider1,'visible','off');
        set(handles.text6,'visible','off');
        set(handles.text7,'visible','off');
        set(handles.text8,'visible','off');
        set(handles.text9,'visible','off');
        set(handles.edit2,'visible','off');
end

% --- Executes during object creation, after setting all properties.
function popupmenu3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popupmenu4.
function popupmenu4_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu4 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu4

w2 = get(handles.popupmenu4,'value');

switch w2
    case 2
        %canny edge dectection
        set(handles.pushbutton1,'visible','off');
        set(handles.pushbutton2,'visible','off');
        set(handles.pushbutton3,'visible','off');
        set(handles.text7,'visible','off');
        set(handles.text4,'visible','off');
        set(handles.slider1,'visible','on');
        set(handles.text8,'visible','on');
        set(handles.text9,'visible','off');
        set(handles.edit2,'visible','off');
        set(handles.slider1,'min',0);
        set(handles.slider1,'value',0.2);
        set(handles.slider1,'max',1);
        Cany= edge(handles.image, 'canny', 0.1, 1.4);
        axes(handles.axes2);
        imshow(Cany,[]);
        
    case 3
        set(handles.pushbutton1,'visible','off');
        set(handles.pushbutton2,'visible','off');
        set(handles.pushbutton3,'visible','off');
        set(handles.text7,'visible','off');
        set(handles.text6,'visible','off');
        set(handles.text4,'visible','off');
        set(handles.slider1,'visible','off');
        set(handles.text8,'visible','off');
        set(handles.text9,'visible','off');
        set(handles.edit2,'visible','off');
        BW = edge(handles.image,'canny');
        [H,T,R] = hough(BW);%extracting lines from hough transform
        
        P  = houghpeaks(H,10,'threshold',ceil(0.4*max(H(:))));
        lines = houghlines(BW,T,R,P,'FillGap',3,'MinLength',15);
        axes(handles.axes2)
        imshow(handles.image,[]);hold on
        for k = 1:length(lines)
            xy = [lines(k).point1; lines(k).point2];
            plot(xy(:,1),xy(:,2),'LineWidth',2,'Color','green');
            plot(xy(1,1),xy(1,2),'x','LineWidth',2,'Color','yellow');
            plot(xy(2,1),xy(2,2),'x','LineWidth',2,'Color','red');
        end
    case 4
        set(handles.pushbutton1,'visible','off');
        set(handles.pushbutton2,'visible','off');
        set(handles.pushbutton3,'visible','off');
        set(handles.text4,'visible','off');
        set(handles.slider1,'visible','off');
        set(handles.text8,'visible','off');
        set(handles.text9,'visible','off');
        a1 = edge(handles.image,'canny');
        set(handles.edit2,'visible','off');
        [centers, radii] = imfindcircles(a1,[10 50]);%extracting circles from hough transform
        axes(handles.axes2)
        imshow(handles.image,[])
        hold on
        viscircles(centers, radii,'EdgeColor','b');
        hold off
        
    case 5
        set(handles.text4,'visible','off');
        set(handles.text5,'visible','off');
        set(handles.slider1,'visible','off');
        set(handles.text6,'visible','off');
        set(handles.text7,'visible','off');
        set(handles.text8,'visible','off');
        set(handles.text9,'visible','off');
        set(handles.edit2,'visible','off');
        set(handles.pushbutton1,'visible','off');
        set(handles.pushbutton2,'visible','off');
        set(handles.pushbutton3,'visible','off');
        set(handles.text4,'visible','off');
        %          figure,
        c= imcontour(handles.image,1);
        axes(handles.axes2);
        imshow(c,[]);
        
    case 6
        set(handles.text4,'visible','off');
        set(handles.text5,'visible','off');
        set(handles.slider1,'visible','off');
        set(handles.text6,'visible','off');
        set(handles.text7,'visible','off');
        set(handles.text8,'visible','off');
        set(handles.text9,'visible','off');
        set(handles.pushbutton1,'visible','off');
        set(handles.pushbutton2,'visible','off');
        set(handles.pushbutton3,'visible','off');
        set(handles.edit2,'visible','off');
        set(handles.text4,'visible','off');
        
        a1=im2bw(handles.image,0.2);
        L = bwlabel(a1);
        Blobs = regionprops(L, 'BoundingBox', 'Area');%shape descriptors
        axes(handles.axes2)
        imshow(a1)
        hold on
        for k = 1 : size(Blobs,1);
            Box = Blobs(k).BoundingBox;
            rectangle('position',[Box(1) Box(2) Box(3) Box(4)],'EdgeColor','r','LineWidth',2);
        end
        
    case 7
        set(handles.text4,'visible','off');
        set(handles.text5,'visible','off');
        set(handles.text9,'visible','off');
        set(handles.slider1,'visible','off');
        set(handles.text6,'visible','off');
        set(handles.text7,'visible','off');
        set(handles.text8,'visible','off');
        set(handles.edit2,'visible','off');
        set(handles.pushbutton1,'visible','off');
        set(handles.pushbutton2,'visible','off');
        set(handles.pushbutton3,'visible','off');
        set(handles.text4,'visible','off');
        points = detectHarrisFeatures(handles.image);%detecting harris corner features
        axes(handles.axes2)
        imshow(handles.image,[]);
        hold on
        plot(points)
        
    case 8
        set(handles.text4,'visible','off');
        set(handles.text5,'visible','off');
        set(handles.text9,'visible','off');
        set(handles.slider1,'visible','off');
        set(handles.text6,'visible','off');
        set(handles.text7,'visible','off');
        set(handles.text8,'visible','off');
        set(handles.pushbutton1,'visible','off');
        set(handles.pushbutton2,'visible','off');
        set(handles.pushbutton3,'visible','off');
        set(handles.text4,'visible','off');
        set(handles.edit2,'visible','off');
        point = detectFASTFeatures(handles.image);%detecting Fast features
        axes(handles.axes2)
        imshow(handles.image,[])
        hold on
        plot(point)
    case 9
        set(handles.text4,'visible','off');
        set(handles.text5,'visible','off');
        set(handles.slider1,'visible','off');
        set(handles.text6,'visible','off');
        set(handles.text7,'visible','off');
        set(handles.text8,'visible','off');
        set(handles.pushbutton1,'visible','off');
        set(handles.pushbutton2,'visible','off');
        set(handles.pushbutton3,'visible','off');
        set(handles.text4,'visible','off');
        set(handles.text9,'visible','off');
        set(handles.edit2,'visible','off');
        point = detectSURFFeatures(handles.image);%detecting SURF features
        points = point.selectStrongest(10);
        
        axes(handles.axes2)
        imshow(handles.image,[])
        hold on
        plot(point)
        
    case 10
        set(handles.text4,'visible','off');
        set(handles.text5,'visible','off');
        set(handles.slider1,'visible','off');
        set(handles.text6,'visible','off');
        set(handles.text7,'visible','off');
        set(handles.text8,'visible','off');
        set(handles.pushbutton1,'visible','off');
        set(handles.pushbutton2,'visible','off');
        set(handles.pushbutton3,'visible','off');
        set(handles.text9,'visible','off');
        set(handles.text4,'visible','off');
        set(handles.edit2,'visible','off');
        
        a = single(handles.image);
        [f,d] = vl_sift(a);%detecting Sift features
        perm = randperm(size(f,2)) ;
        sel = perm(1:50) ;
        axes(handles.axes2)
        imshow(double(a)/255);hold on
        vl_plotframe(f(:,sel)) ;
end
% --- Executes during object creation, after setting all properties.
function popupmenu4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popupmenu5.
function popupmenu5_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu5 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu5


w3 = get(handles.popupmenu5,'value');

switch w3
    case 2
        %camera calibration
        folder =uigetdir();
        imageFileNames = [];
        for i = 1:9
            s = strcat('chessboard0',num2str(i),'.jpg');
            imageFileNames{i} = fullfile(folder,s);
        end
        [imagePoints, boardSize, imagesUsed] = detectCheckerboardPoints(imageFileNames);
        imageFileNames = imageFileNames(imagesUsed);
        
        squareSize = 30;  % in units of 'mm'
        worldPoints = generateCheckerboardPoints(boardSize, squareSize);
        cameraParams = estimateCameraParameters(imagePoints, worldPoints);
        axes(handles.axes1)
        showExtrinsics(cameraParams, 'CameraCentric');
        originalImage = imread(imageFileNames{1});
        undistortedImage = undistortImage(originalImage, cameraParams);
        axes(handles.axes2)
        imshow(undistortedImage );
        
    case 3
        %matching two images using surf
        I1 = handles.image;
        I2 = imresize(imrotate(I1,-20),1.2);
        points1 = detectSURFFeatures(I1);
        points2 = detectSURFFeatures(I2);
        
        [f1,vpts1] = extractFeatures(I1,points1);
        [f2,vpts2] = extractFeatures(I2,points2);
        indexPairs = matchFeatures(f1,f2) ;
        matchedPoints1 = vpts1(indexPairs(:,1));
        matchedPoints2 = vpts2(indexPairs(:,2));
        axes(handles.axes2)
        showMatchedFeatures(I1,I2,matchedPoints1,matchedPoints2);
        legend('matched points 1','matched points 2');
        
    case 4
        [filename,pathname]= uigetfile({'*.jpg;*.tif;*.png;*.gif','All Image Files';...
            '*.*\','All Files' });
        image=imread(fullfile(pathname,filename));
        image1 = rgb2gray(image);
        
        [filename,pathname]= uigetfile({'*.jpg;*.tif;*.png;*.gif','All Image Files';...
            '*.*\','All Files' });
        image=imread(fullfile(pathname,filename));
        image2 = rgb2gray(image);
        [f,m] = sift_mosaic(image1, image2);
        axes(handles.axes1)
        imshow(f)
        axes(handles.axes2)
        imagesc(m)
end

% --- Executes during object creation, after setting all properties.
function popupmenu5_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popupmenu6.
function popupmenu6_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu6 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu6
w4 = get(handles.popupmenu6,'value');

switch w4
    case 2
        [filename,pathname]= uigetfile({'*.jpg;*.tif;*.png;*.gif','All Image Files';...
            '*.*\','All Files' });
        image=imread(fullfile(pathname,filename));
        I1= rgb2gray(image);
        
        [filename,pathname]= uigetfile({'*.jpg;*.tif;*.png;*.gif','All Image Files';...
            '*.*\','All Files' });
        image=imread(fullfile(pathname,filename));
        I2= rgb2gray(image);
        
        points1 = detectSURFFeatures(I1);
        points2 = detectSURFFeatures(I2);
        
        [f1,vpts1] = extractFeatures(I1,points1);
        [f2,vpts2] = extractFeatures(I2,points2);
        indexPairs = matchFeatures(f1,f2) ;
        matchedPoints1 = vpts1(indexPairs(:,1));
        matchedPoints2 = vpts2(indexPairs(:,2));
        
        
        %  calculating fundamental matrix
        [fLMedS, inliers] = estimateFundamentalMatrix(matchedPoints1, matchedPoints2, 'NumTrials', 4000);
        fLMedS
        set(handles.edit2,'visible','on');
        set(handles.edit2, 'String', num2str(fLMedS))
        %         axes(handles.axes2)
        %         imshow(fLMedS,[]);
        
        
    case 3
        [filename,pathname]= uigetfile({'*.jpg;*.tif;*.png;*.gif','All Image Files';...
            '*.*\','All Files' });
        image=imread(fullfile(pathname,filename));
        I1= rgb2gray(image);
        
        [filename,pathname]= uigetfile({'*.jpg;*.tif;*.png;*.gif','All Image Files';...
            '*.*\','All Files' });
        image=imread(fullfile(pathname,filename));
        I2= rgb2gray(image);
        
        points1 = detectSURFFeatures(I1);
        points2 = detectSURFFeatures(I2);
        
        [f1,vpts1] = extractFeatures(I1,points1);
        [f2,vpts2] = extractFeatures(I2,points2);
        indexPairs = matchFeatures(f1,f2) ;
        matchedPoints1 = vpts1(indexPairs(:,1));
        matchedPoints2 = vpts2(indexPairs(:,2));
        matchedPoints1=matchedPoints1.Location;
        matchedPoints2=matchedPoints2.Location;
        [fLMedS, inliers] = estimateFundamentalMatrix(matchedPoints1, matchedPoints2, 'NumTrials', 4000);
        
        %         axes(handles.axes1)
        %plotting epipolar lines
        figure,
        imshow(I1);hold on
        plot(matchedPoints1(inliers,1), matchedPoints1(inliers,2), 'go')
        epiLines = epipolarLine(fLMedS', matchedPoints2(inliers, :));
        points = lineToBorderPoints(epiLines, size(I1));
        line(points(:, [1,3])', points(:, [2,4])');
        hold off
        
        %         axes(handles.axes2)
        figure,
        imshow(I2);hold on
        plot(matchedPoints2(inliers,1), matchedPoints2(inliers,2), 'go')
        epiLines = epipolarLine(fLMedS, matchedPoints1(inliers, :));
        points = lineToBorderPoints(epiLines, size(I2));
        line(points(:, [1,3])', points(:, [2,4])');
        hold off
end


% --- Executes during object creation, after setting all properties.
function popupmenu6_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
w1 = get(handles.popupmenu3,'value');
switch w1
    case 2
        set(handles.pushbutton1,'enable','on');
        se = strel('ball',15,5);
        Open=imopen(handles.image,se);
        axes(handles.axes2);
        imshow(Open,[]);
    case 3
        set(handles.pushbutton1,'enable','on');
        se = strel('ball',15,5);
        close=imclose(handles.image,se);
        axes(handles.axes2);
        imshow(close,[]);
    case 4
        
        set(handles.pushbutton1,'enable','on');
        se = strel('ball',15,5);
        dilate=imdilate(handles.image,se);
        axes(handles.axes2);
        imshow(dilate,[]);
        
    case 5
        set(handles.pushbutton1,'enable','on');
        se = strel('ball',15,5);
        erode=imerode(handles.image,se);
        axes(handles.axes2);
        imshow(erode,[]);
end


% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
w1 = get(handles.popupmenu3,'value');
switch w1
    case 2
        set(handles.pushbutton2,'enable','on');
        se = strel('Diamond',10);
        Open=imopen(handles.image,se);
        axes(handles.axes2);
        imshow(Open,[]);
    case 3
        set(handles.pushbutton1,'enable','on');
        se = strel('Diamond',10);
        close=imclose(handles.image,se);
        axes(handles.axes2);
        imshow(close,[]);
    case 4
        
        set(handles.pushbutton1,'enable','on');
        se = strel('Diamond',10);
        dilate=imdilate(handles.image,se);
        axes(handles.axes2);
        imshow(dilate,[]);
        
    case 5
        set(handles.pushbutton1,'enable','on');
        se = strel('Diamond',10);
        erode=imerode(handles.image,se);
        axes(handles.axes2);
        imshow(erode,[]);
end

% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
w1 = get(handles.popupmenu3,'value');
switch w1
    case 2
        set(handles.pushbutton3,'enable','on');
        se = strel('square',11);
        Open=imopen(handles.image,se);
        axes(handles.axes2);
        imshow(Open,[]);
    case 3
        set(handles.pushbutton1,'enable','on');
        se = strel('square',11);
        close=imclose(handles.image,se);
        
        axes(handles.axes2);
        imshow(close,[]);
    case 4
        
        set(handles.pushbutton1,'enable','on');
        se = strel('square',11);
        dilate=imdilate(handles.image,se);
        axes(handles.axes2);
        imshow(dilate,[]);
        
    case 5
        set(handles.pushbutton1,'enable','on');
        se = strel('square',11);
        erode=imerode(handles.image,se);
        axes(handles.axes2);
        imshow(erode,[]);
end


% --- Executes on slider movement.
function slider1_Callback(hObject, eventdata, handles)
% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


w= get(handles.popupmenu2,'value');
switch w
    case 2
        set(handles.slider1,'enable','on');
        slide5= get(hObject,'Value');
        n=imnoise(handles.image,'salt & pepper', slide5);
        axes(handles.axes2);
        imshow(n,[]);
        
    case 7
        set(handles.slider1,'enable','on');
        slide1= get(hObject,'Value');
        Blur = imgaussfilt(handles.image,slide1);
        axes(handles.axes2);
        imshow(Blur,[]);
        %        case 8
        %         set(handles.slider1,'enable','on');
        %          slide2= get(hObject,'Value');
        %         edgeIm = imfilter(handles.image,  slide2);
        %         axes(handles.axes2);
        %         imshow(edgeIm,[]);
    case 9
        set(handles.slider1,'enable','on');
        slide3= get(hObject,'Value');
        L = fspecial('laplacian',slide3);
        edgeIm = imfilter(handles.image,  L);
        axes(handles.axes2);
        imshow(edgeIm,[]);
    case 10
        set(handles.slider1,'enable','on');
        slide4= get(hObject,'Value');
        sharp=imsharpen(handles.image,'Amount',slide4);
        axes(handles.axes2);
        imshow(sharp,[]);
end
w2 = get(handles.popupmenu4,'value');
switch w2
    case 2
        set(handles.slider1,'enable','on');
        slide4= get(hObject,'Value');
        Cany= edge(handles.image, 'canny', slide4, 1.4);
        axes(handles.axes2);
        imshow(Cany,[]);
        
end

% --- Executes during object creation, after setting all properties.
function slider1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on button press in pushbutton4.
function pushbutton4_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
s = get(handles.popupmenu1,'value');
switch s
    case 4
        
        v = getappdata(0,'v');
        axes(handles.axes1)
        while(~isDone(v))
            f = step(v);
            imshow(f)
            pause(0.02)
        end
end


% --- Executes on button press in pushbutton5.
function pushbutton5_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on selection change in listbox2.



function edit2_Callback(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit2 as text
%        str2double(get(hObject,'String')) returns contents of edit2 as a double
set(handles.edit2,'visible','on');
C= str2double(get(hObject, 'String'));
if isnan(C)
    set(hObject, 'String', 0);
    errordlg('Input must be a number','Error');
end
handles.C=C
guidata(hObject,handles)

% --- Executes during object creation, after setting all properties.
function edit2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
